//import UIKit
import Foundation
/*
struct Rectangle
{
    var length:Double
    var breadth:Double
    
    var area:Double
    {
        get {
            return length*breadth
        }
    }
}

let result=Rectangle(length:5,breadth:4)
print("the area of reactangle is \(result.area)")
//debugPrint("the area of Rectangle is =\(result.area)")

*/


//circle example

struct Circle
{
  var radius:Double=0
  
  var area:Double {          // computed properties should never be initialized
  get        //getting teh value
  {
      return radius*radius*Double.pi
  }
  set             //setting the value of radius
   {
      radius=sqrt(newValue/Double.pi)
   } }
 }
  var cir = Circle(radius:4)
  //cir.radius=5                          //can be declared in any way
  print(cir.area)
  cir.area=40
  print(cir.radius)
  
  
  
  
  
  