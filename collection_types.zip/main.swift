//Array Concept
/*
 var names:[String]=["Prashant","aman","pranay","ashok"]
 var num:[Int]=[]
 var numArray=[1,2,3,4,5,6,7,8]
 
 print(names.count)
 names.insert("akshay",at:3)
 //print(names)
 print(names[3])
 
 print(names.append("naman"))
 print(names)
 print(numArray.firstIndex(of:4)!)   //to remove optional we are using a ! mark to unwrap
 numArray.remove(at:3)
 numArray.insert(5,at:4)
 print(numArray)
 
 //Printing usinf for loop
 
 for item in names {
     print(item)
     //print("the names are \(names)")
 }
 /* #****************************************************************************************# */
 */
 
 
 /*
//set
var numbers=Set([1,2,3,4,5,6,1,2])
var num1:Set=["pj","prashant","naman","bhaskar"]
print(num1)

print(numbers.insert(7))
print(numbers.remove(6))
print(numbers)

//Printing using a fir llop  same as Array
for item in  num1 {
    print(item)
}

// Using the property of sets like union ,istersection,subSet,superset etc

var a=Set([1,2,3,4])
var b=Set([1,3,2])

b.isSubset(of:b)
a.isSuperset(of:b)
a.isDisjoint(with: b)

let newArray=a.intersection(b)
a.union(b).sorted()
a.intersection(b).sorted()

print(a.subtracting(b))
print(a.symmetricDifference(b).sorted())

*/

//  ************************************************************************************************


//Dictionary

var namesOfIntegers: [Int: String] = [:]
var fruits: [String: String] = ["a": "apple", "b": "banana"]    //Declared the type of string to be used 



var playerScore = [
"prashant":123,
"aman":55,
"prateek":59
]


playerScore["aksah"]=34    //adding a new key value pair in a Dictionary

playerScore["aman"]=84    //updating the value of a key 
playerScore.updateValue(66,forKey:"prateek")   //updating using updateValue


playerScore["aman"]=nil    //removing from the Dictionary

print(playerScore)