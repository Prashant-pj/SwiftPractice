/*
//closures continue 
func add(_ x:Int,_ y:Int)
{
    print(x+y)
}
add(4,7)

var f1:(Int,Int) ->Void

f1=add    // asssignig the add method to f1

f1(4,7)
*/
// __________________________________________________________________________

func cube(_ x:Int) ->Int
{
    return x*x*x
}

var output=cube(3)
print("output is :",output)

func factorial(_ n:Int) ->Int
{  
var fact=1
    for i in  1..<n
    {
        fact = fact * i
    }
   // print(fact)
   return fact
}
var f=factorial(5)
print("factorial is :",f)


var myVar : ((Int)->Int)?
var myValue:Int
print("enter the number:")
myValue=Int(readLine()!)!

print("enter 1 for cube and 2 for factorial")

var choice=Int(readLine()!)!

if choice==1
{
    myVar=cube
}
if choice==2
{
    myVar=factorial
}
else 
{
    print("unexpected choice ")
}

if (myVar != nil)
{

let a=myVar!(myValue)
print("the output is:",a)
    
}
  
//CLOSURES EXPRESSION  -- anonymous function

var closure1 =
{
    print("hello prashant")
}

closure1()

var closure2 = {
    (_ a:Int) ->Int
    
    in
    
    let square=a*a
    return square
}

let res=closure2(3)
print("square is",res)
    
    
myVar=closure2   //can assign as have same type of data type and return type
print("result of second square is",myVar!(4))
    
    
func doSomething(_ n:Int,_ f:(Int)->Int)  // func containing one var and other func as parameter
{
    var r=n*5
    r=r+f(n)
    print("result is",r)
    
}
doSomething(3,cube)      
doSomething(5,factorial)
doSomething(6,closure2)






