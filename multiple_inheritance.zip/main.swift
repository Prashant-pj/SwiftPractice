protocol iosSkills
{
    func iosKnowledge()
}

protocol androidSkills
{
    func androidKnowledge()
}

class Employee
{
    var name:String=""
    
    
    init(_ name:String)
    {
        self.name=name
    }
    
    //func getDeatails()
   func androidKnowledge()
    {
        print("Employee name is \(name)")
    }
}


/*class androidDevelpoer:Employee
{
    func getSkill()
    {
        print("knows kotlin well")
    }
}*/

//class iosDeveloper:Employee,androidDevelpoer       //directly the multiple iheritance is not supported so we do using protocol

class iosDeveloper:Employee, androidSkills
{
    //var role:String=""
    override func androidKnowledge()
    {
        print("also has a knowledge of android")
    }
    func getSkill()
    {
        print("knows swift well")
        
    }
}
let emp=iosDeveloper("prashant")
emp.getSkill()
//emp.getDeatails()
emp.androidKnowledge()





/*
extension androidSkills{
    
}*/
