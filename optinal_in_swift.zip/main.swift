//optional

//either contains value or a nil
/*
var age:Int?=22                  //using ? with any datatype makes is optional
var name:String="prashant "
var roll:Int?=nil                //simply means nothing or empty 
  
print(age!)                      //unwrapping,we confirms thta this is not nil
print(name)
print(roll)
*/
var age="30"
let a=Int(age)
//a!*4                           //cant directy perform any operation
print(age)
var name="22 years old"
print(name)


if let age1=Int("40")
{
    print(age1)
}


func optioalTest(_ name:String?)
{
    if name==nil
    {
        print("it is nil")
    }
    else
    {
        print("name is \(name!)")
    }
}
optioalTest(nil)

