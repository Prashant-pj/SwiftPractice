

//simple searching by iterating  only
//var numArray=[1,43,53,3,7]
/*
var numArray:[Int]=[]   // taking array as input from an user
for i in 1...5
{
    print("enter the no \(i)")
    numArray.append(Int(readLine()!)!)     // append  element in an array
}

//let num=3       
print("enter a no to search")
var num=Int(readLine()!)!     //num from user

for i in 0..<numArray.count
{
        if(numArray[i]==num)
        {
            print("element fount at index \(i)")
        }
        
     }
 */
 
  /* 
//linear searching   using function

func linearSearch(_ array:[Int],_ num:Int) ->Int?    //use of optional
{
    for i in 0..<array.count
    {
        if(array[i]==num)
        {
            return i
        }
    }
    return nil
}

var  array=[23,5,24,63,4]
var index=linearSearch(array,5)
print(index ?? -1)     //to set  for an optional
*/
//*********************************************************************************************

//Binary Search  (work with an sorted array)
var numArray = [3,30,31,43,47,54]

func binarySearch(_ numArray:[Int],_ key:Int) ->Bool    //searchimg based on key value
{
      if numArray.count==0{
       return false
}
    let minIndex=0
    let maxIndex=numArray.count-1
    let midIndex=maxIndex/2
    let midValue = numArray[midIndex]
    
    guard key<numArray[minIndex] || key>numArray[maxIndex] else 
    {
      print("not in an array")
      return //false
    }
    
    guard key>midValue else
    {
        let slice = Array(numArray[minIndex+1...maxIndex])  // slicing the array based on key value 
        return binarySearch(slice,key)
        
    }
    if key<midValue 
    {
        let slice = Array(numArray[minIndex...midIndex-1])
        return binarySearch(slice,key)
    }
    if key==midValue
    {
        print("\(key) found in the array")
        return true
    }
    
    return false
}

print(binarySearch(numArray,3))


//__________________________________________________________________________________________
    
  
/*
var numArray = [3,30,31,43,47,54]

func binarySearch(_ numArray:[Int],_ key:Int) ->Bool    //searchimg based on key value
{
      if numArray.count==0{
       return false
}
    let minIndex=0
    let maxIndex=numArray.count-1
    let midIndex=maxIndex/2
    let midValue = numArray[midIndex]
    
    if key<numArray[minIndex] || key>numArray[maxIndex]
    {
      print("not in an array")
      return false
       
    }
    if key>midValue
    {
        let slice = Array(numArray[minIndex+1...maxIndex])  // slicing the array based on key value 
        return binarySearch(slice,key)
        
    }
    if key<midValue
    {
        let slice = Array(numArray[minIndex...midIndex-1])
        return binarySearch(slice,key)
    }
    if key==midValue
    {
        print("\(key) found in the array")
        return true
    }
    
    return false
}

print(binarySearch(numArray,34))

*/


