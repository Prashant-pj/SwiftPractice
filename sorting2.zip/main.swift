

var array1=[34,68,64,33]

for i in 0..<array1.count
{
 
  for j in (i+1)..<array1.count

{
    if(array1[i]>array1[j])
    {
     swap(array1[i],array1[j])
      
  }
}

}

print(array1)