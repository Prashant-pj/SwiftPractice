// understanding Enumeration using swift


//enum  declaration
enum direction {
    case north
    case south
    case east
    case west
}

var dir=direction.east


//enum declaration

enum  fruits{
       case apple,orange,mango,pineapple,grapes
}

//Enum with switch

dir = .north
switch dir
{
    case .north:
    print("its a north direction")
    
    case .south:
    print("its a south direction")
    
    case .east:
    print("its a east direction")
    
    case .west:
    print("its a west direction")
    
    // default:               //condition where default will be needed
    // print("Invalid")
}



//****************************************************************************************************************
//Enum second class
// define enum 
enum Season {
  case spring, summer, autumn, winter
}
var currentSeason: Season
currentSeason = Season.summer

print("Current Season:", currentSeason)

//Enum second example
enum PizzaSize {
  case small, medium, large
}

var size = PizzaSize.medium

switch(size) {
  case .small:
    print("I ordered a small size pizza.")

  case .medium:
    print("I ordered a medium size pizza.")

   case .large:
     print("I ordered a large size pizza.");
}


//enum iterating over all classes

enum Season: CaseIterable {    //case protocol to iterate over a enum
  case spring, summer, autumn, winter 
}

// for loop to iterate over all cases
for currentSeason in Season.allCases {
  print(currentSeason)
}


//Enum example with raw value

enum Size : Int {
  case small = 10
  case medium = 12
  case large = 14
}

var result = Size.small.rawValue
print(result)

//enum with associated value

enum Laptop {
  case name(String)
  case price (Int)
}
var brand = Laptop.name("Razer")
print(brand)

var offer = Laptop.price(1599)
print(offer)
