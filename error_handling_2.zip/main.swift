

/*enum BankingError: Error {
    case invalidSelection
    case insufficientFunds(moneyNeeded: Int)
    case outOfService
}


struct Item {
    var cash: Int
    var totalBranch: Int
}

class Bank {
    var bankName = [
        "Sbi": Item(cash: 12334,totalBranch : 7),
        "Icci": Item(cash:17650, totalBranch: 4),
        "Pnb": Item(cash:34667, totalBranch: 11)
    ]
    var moneyDeposited = 0

    func withdraw(name:String) throws {
        guard let item = bankName[name] else {
            throw BankingError.invalidSelection
        }
         
        guard item.totalBranch > 0 else {
            throw BankingError.outOfService
        }

        guard item.cash <= moneyDeposited else {
            throw BankingError.insufficientFunds(moneyNeeded: item.cash - moneyDeposited)
        }

        moneyDeposited -= item.cash

        var newItem = item
        newItem.totalBranch -= 1
        bankName[name] = newItem

        print("fething \(name)")
    }
}



do {
    let bank=try Bank()
    bank.moneyDeposited=8
    print("success")
} 
catch BankingError.invalidSelection
{
     print("Invalid Selection")
}
 catch BankingError.outOfService
 {
    print("Out of Stock.")
} 
catch BankingError.insufficientFunds(let moneyNeeded) 
{
    print("Insufficient funds. Please insert an additional \(moneyNeeded) coins.")
} catch 
{
    print("Unexpected error: \(error).")
}

*/

/*
enum customErrors:Error{
    case invalidUrl
    case urlEmpty
    case other
}

func checkingError(urlString:String?) throws ->Bool
{
    guard urlString!.isEmpty else 
    {
        print("a")
        throw customErrors.urlEmpty
        
    }
    
    guard urlString != nil else
    {
        print("b")
        throw customErrors.invalidUrl
        
    }
    return false
}


func callingError()
{
    let urlString1="https://www.ggogle.com"
    
    do {
        try checkingError(urlString:urlString1)
        
    }
  /*  catch customErrors.invalidUrl
    {
        print("invalid error")
    }
    catch customErrors.urlEmpty
    {
        print("url is empty")
    }
    */
    catch
    {
        print(error)
    }
     /*let result=try? checkingError(urlString:"")
     print(result!)
     */
}

*/



enum InvalidNumberError : Error{
        case even
        case tooBig
   }

  

   func printSmallNumber(_ x:Int) throws{

        if x % 2 == 0 {
             throw InvalidNumberError.even
        }
        else if x > 100 {
             throw InvalidNumberError.tooBig
        }

        print("number is \(x)")
   }
   
    do{
        try printSmallNumber(67)
    }catch InvalidNumberError.even{
        print("Number is Even")
    }catch InvalidNumberError.tooBig{
        print("Number is greater tha 100")
    }catch{
        print("some error")
    }
    
    