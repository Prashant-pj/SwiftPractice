
//Nested Types
struct Fruit
{
     enum RedFruit:String{
        case apple="app",strawberry="stb",chilli="chi"
        
        
        enum size:Int{
            case small=1,medium,big
        }
         
     }
     
     var myFruit:RedFruit?
     var myFruitSize:RedFruit.size?
     
     var description:String {
         return "myFruit=\(myFruit?.rawValue),size=\(myFruitSize?.rawValue)"
         }
         
}

print(Fruit.RedFruit.apple.rawValue)
print(Fruit.RedFruit.size.big.rawValue)


var fruit=Fruit()
fruit.myFruit=Fruit.RedFruit.chilli
fruit.myFruitSize=Fruit.RedFruit.size.small

print(fruit.description)