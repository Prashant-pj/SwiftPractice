//Understanding the function in swift

/*func myFunc()
{
    let a=10
    let b=34
    print("the result is \(a+b)")
}

myFunc
*/
/*
func myFunc() ->Int 
{
    let a = 43
    let b = 7
    return a+b
}
 let result=myFunc()
 print(result)
 
 */
 
 
 func myFunc(a:Int) ->Int
 {
     let b=6
     return a+b
 }
 let res=myFunc(a:4)
 print(res)
 
 func myFunc1(a:Int)
 {
     let b=10
     print("output is:",a+b)
 }
 myFunc1(a:7)
 
 
 func myfunc2(a:Int,b:Int)
 {
     print("the a and b are",a, b)
 }
 myfunc2(a:4,b:7)
 
 func myFunc3(a:Int=5,b:Int=8) ->Int   //specifying the default value 
 {
    return a+b
 }
 
 let new=myFunc3(a:4)   //let new =myFunc3(a:3)
 print(new)
 
 
 func myFunc4(_ a:Int,_ b:Int)
 {
     print(a*b)
 }
 
 myFunc4(3,6)
 
 
 func myFunc5(name:String,roll:Int)
 
 {
     print("name and roll no are",name ,roll)
 }
 myFunc5(name:"prashant",roll:7)
 
 /*
 func myFunc6(_ name:String,_ roll:Int) ->(name:String,roll:Int)?
 {
   //  return "the name" + name + "and roll is " + roll
      return name+roll
 let boy=myFunc6("pj",5)
 print(boy)
 */
 func greetAgain(person: String) -> String {
    return "Hello again, " + person + "!"
}
print(greetAgain(person: "prashant"))

//***********************************************************************************************************

/*
func minMax(array: [Int]) -> (min: Int, max: Int) {
    var currentMin = array[0]
    var currentMax = array[0]
    for value in array[1..<array.count] {
        if value < currentMin {
            currentMin = value
        } else if value > currentMax {
            currentMax = value
        }
    }
    return (currentMin, currentMax)
}
*/


func walk(_ direction:String,_ steps:Int) -> String{
    return "You have walked " + String(steps) + " steps to the " + direction
}

let resultStr:String = walk("North",5)

print(resultStr) 
