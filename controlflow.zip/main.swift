

/*
var names=["prashant","pankaj","abhinav","shubham"]

for item in names {

    print("hello \(item)")
} 

let AnimalAndLegs = ["cat":4,"kangarro":2,"ant":6]

for (animal,legs) in AnimalAndLegs
{
    print("the \(animal) have legs \(legs)")
}

for index in 1...5 {
    print("\(index) times 5 is \(index*5)")
}
*/
// **************************************************************************************************************
//while Loop
/*
var i=0
var N:Int
print("enter the number")
N=Int(readLine()!)!
while(i<N)
{   
    i+=1
    print("the numbers are \(i)")// printin using the string manupulation
    
    print("the numbers are",i)
}

for _ in 1...N {
    print(N)
    
}

/*
let  time=60
for i in 1..<time{
    print(i)
}



*/
*/
print("*****************************************************************************************")

/*// for loop with pattern

 var pattern:String="*"
 var height:Int=5
  for i in 1...height  {
    var temp:String=""
    for _ in 1...i
    {
         temp=temp+pattern
    }
     print(temp)
  }
 */
/* 
//Finding sum  of a number using for in loop

var  sum=0
var N = 4
for i in 1...N {
    sum+=i
    //print(sum)
}
print(sum)


//For loop using stride __FUNCTION__
N = 12
for i in stride(from:1,to:N,by:3)   // printing very value but with a gap of 3 steps as specfied using stride
{
    print("using step of 3:",i)
}
 
 print("******************************************************************************************")

//  for in loop in reverrse order
for i in (1...N).reversed()
{
    print(i)
}


*/
//using repeat while
var i=2,N=8
repeat {     //same as do while of oter language
    i=i+1
    print(i)
} while(i<=N)


/*
var cashOnHand:Double = 2000
var runningCash:Double
var percentGain:Double = 10
var yearsToInvest:Int = 5
var yearsElapsed:Int = 0

runningCash = cashOnHand
percentGain = percentGain / 100

repeat {
    runningCash = runningCash + (runningCash * percentGain)
print(runningCash)
    yearsElapsed+=1
} while yearsElapsed < yearsToInvest


*/
