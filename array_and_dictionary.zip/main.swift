var myarr=[String]()
myarr=["pj","sj","aj","az"]
print(myarr)

var a="Dog"
var b="cat"
var c="Bird"

//a="My"+a
var myArray=["dog","cat","Bird"]
for counter in 0..<myArray.count//0...2
{
   myArray[counter]="my" + myArray[counter]
    print(myArray[counter])
}


//Dictionary
var myDictionary=[String:String]()
myDictionary["sjd 293"]="Red Ferrari"
myDictionary["pkj 2345"]="Blue swift"

let myCar=myDictionary["sjd 293"]
//To replace a value
myDictionary["sjd 293"]="black Ferrari"
for (key,value) in myDictionary
{
    print(key)
}

/*
// Exampele 2
var namesOfIntegers: [Int: String] = [:]
namesOfIntegers[16] = "sixteen"
var airports: [String: String] = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]
print("The airports dictionary contains \(airports.count) items.")


var capitalCity = ["Nepal": "Kathmandu", "Italy": "Rome", "England": "London"]
print(capitalCity)

// dictionary with keys and values of different data types
var numbers = [1: "One", 2: "Two", 3: "Three"]
print(numbers)

//to update the Dictionary 
var capitalCity = ["Nepal": "Kathmandu", "England": "London"]
print("Initial Dictionary: ",capitalCity)

capitalCity["Japan"] = "Tokyo"

print("Updated Dictionary: ",capitalCity)
print(capitalCity["Japan"]
//___________________________________________________________________________________________
var cities = ["Nepal":"Kathmandu", "China":"Beijing", "Japan":"Tokyo"]

print("Dictionary: ", cities)
// cities.keys return all keys of cities
var countryName  = Array(cities.keys)
print("Keys: ",countryName)

*/
let ages=["pj":22,"sj":43,"rj":32]
print(ages["pj"]!)

if let arrayAges=ages["pj"]
{
    print("pj is \(arrayAges) years old")
}

//Tuples
let (first,second)=("prashant","jha")
print(first)
let (first,_)=("prashant","jha")
print(second)
let (_,second)=("prashant","jha")
print(second)

