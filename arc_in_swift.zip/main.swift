/*
class Employee
{
    var empId:Int=0
    var salary:Float=0
    init(){
    
    }
    init(_ empId:Int,_ salary:Float)
    {
        self.empId=empId
        self.salary=salary
    }
    deinit     //executes just before object is deleted from the memory
    { 
        print("hello i am going out of memory")
    }
}
var e1:Employee?=Employee(101,345634)
print(e1!.empId,e1!.salary)
var e2:Employee?=e1
e2!.salary=9876543

print(e1!.salary)


e1=nil
e2=nil

//print(e1!.empId)   //error as object no longer present

*/

// _________________________________________________________________________________________________________

/*

class Person
{ 
    var name:String
    weak var job:Job?    //weak is to avoid strong reference  and to call deinit
    init(_ name:String)
    {
        debugPrint("init method  is called")
        self.name=name
    }
    func printName()
    {
        print("name of a person is \(name)")
    }
    deinit
    {
        print("deinit is called ")
    }
}

var result1:Person?
var result2:Person?

if (1==1)
{
let result=Person("prashant")
result1=result
result2=result
result.printName()
}

result1?.printName()
result1=nil     //when bacomes nil then deinit will be be called
result2=nil
*/
//________________________________________________________________________________________________________________________


//Arc example of strong reference cycle and use of weak
/*
class Person
{
    var name:String
    weak var job:Job?    //weak is to avoid strong reference  and to call deinit
    init(_ name:String)
    {
        debugPrint("init method  is called")
        self.name=name
    }
    func printName()
    {
        print("name of a person is \(name)")
    }
    deinit
    {
        print("deinit is called ")
    }
}
class Job
{
    var jobDescription:String
    var person:Person?
    init(_ des:String)
    {
        debugPrint("init method of job is called")
        jobDescription=des
    }
    func description()
    {
        print("job of a  a person is \(jobDescription)")
    }
    deinit
    {
        print("deinit is called ")
    }
}
if(1==1)
{
let objPerson=Person("aniket")
let objJoB=Job("software engg")
objPerson.job=objJoB
objJoB.person=objPerson
}
*/
// ________________________________________________________________________________________________
/*
class Account {

    // MARK: - Properties

    var plan: Plan
}
class Plan {
    unowned var account: Account
    init(account: Account) {
        self.account = account
    }
}

*/
/*
class Customer
{
    let name: String
    var card: CreditCard?
    
    init(name: String) 
    {
    print("init of Customer is called")
    self.name = name
    }
    deinit 
    { 
    print("\(name) is being deinitialized")
    }
}
class CreditCard {
    let number:Int
    unowned let customer: Customer
    
    init(number:Int ,customer: Customer) 
    {
    print("init of CreditCard is called ")
        self.number = number
        self.customer = customer
    }
    deinit 
    {
    print("Card #\(number) is being deinitialized")
    }
}
var cus: Customer? = Customer(name: "prashant")
cus!.card = CreditCard(number: 1234, customer: cus!)
cus=nil

*/
//_________________________________________________________________________________________________________________________

//unowned reference and implicitely unwrapped optional Properties
class Country 
{
    let name:String
    var captailCity:City!
    
    init(name:String,capitailName:String)
    {
        self.name=name
        self.captailCity=City(name:capitailName,country:self)
    }
}
class City
{
let name:String
unowned let country:Country
init(name:String,country:Country)
{
    self.name=name
    self.country=country
}
} 
var coun1=Country(name:"India",capitailName:"New Delhi")
print("\(coun1.captailCity.name) is the captail of \(coun1.name)")

