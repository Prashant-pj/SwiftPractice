// Taking Input from user using readLine 

/*
var name:String=""
print("enter your name")
name = readLine()!

print("hello Mr \(name) we welcomes you" )

*/

//String Mutability and String concatenation
var variableString = "Horse"
variableString += " and carriage"

let string1 = "hello"
let string2 = " there"
var welcome = string1 + string2

print(variableString)
print(welcome)


print(#"6 times 7 is \#(6 * 7)."#)
print("6 times 7 is \(6 * 7).")





