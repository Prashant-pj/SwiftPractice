//Swift assiciated types and opaque types
/*
struct genericStruct<T>
{
    var property: T?
}

//calling explicitly
let a=genericStruct<Bool>()

//calling implicitly
let b=genericStruct(property:"pj")


//normal protocol

protocol normalProtocol
{
    var property:String {get set}
}
class normalClass:normalProtocol
{
    var property:String = "prashant"  //can be of specific type only in case of normal protocol
}
*/



/*
//use of associated type in generic protocol-

protocol genericProtocol
{
    associatedtype myType
    var anyproperty:myType {get set}
}

struct someStruct:genericProtocol
{
var anyproperty="prashant"
}
struct newStruct:genericProtocol
{
    var anyproperty=2312
}

let newSt=someStruct()
print(newSt)

let newInt=newStruct()
print(newInt)


struct otherStruct:genericProtocol
{
    typealias myType=Bool
    var anyproperty=true
}

//_________________________________________________________________________________________________
//Another Example
protocol product
{
    associatedtype code
    var productCode:code {get}
    func description()
}

struct laptop:product
{

   typealias code=String
   var productCode:String
    func description()
    {
        print ("this is a laptop")
    }
}
struct keyboard:product
{
    typealias code=Int
    var productCode:Int
    func description() ->String
    {
        "this is a keyboard"
    }
    
}

struct factory{
    func makingProduct() -> some product   //using opaque(some) we are able to hide the return type from real world
    {
        return laptop(productCode:"itsPJ")
    }
    
    func makingProduct() ->laptop
    {
        return laptop(productCode:"pjpj")
    }
    func makingProduct() ->keyboard
    {
        return keyboard(productCode:234)
    }
}



/*
func squareArrayElement<T:Numeric>(array:Array<T>) ->LazyMapSequence<Array<T>,T>
{
    array.lazy.map {$0 * $0}
}
*/

func squareArrayElement<T:Numeric>(array:Array<T>) ->some Sequence
{
    
}

*/
// -------------------------------------------------------------------------------------------------------
/*
protocol Shape {
func describe() -> String
}

struct Square: Shape {
func describe() -> String {
return "I ’m a square."
}
}

struct Circle: Shape {
func describe() -> String {
return "I’m a circle."
}
}

func makeShape() -> some Shape 
{
return Circle()
}
let shape = makeShape()
print(shape.describe())
*/
// _________________________________________________________________________________________________

protocol Shape {
associatedtype Color
var color: Color { get }
func describe() -> String
}

struct Square: Shape {
var color: String
func describe() -> String {
return "I’m a square and have four sides of same lengths."
}
}

struct Circle: Shape {
var color: Int

func describe() -> String {
return "I’m a circle. I look like a perfectly round"
}

}
func makeShape() ->some Shape
{
return Square(color: "Yellow")
}
let output=makeShape()
print(output.describe())
