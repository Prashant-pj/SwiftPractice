//leap year code

var year:Int;
print("enter year")
year=Int(readLine()!)!

if year%400==0
{
    print("\(year) is leap year")
}
else if (year%4==0 && year%100 != 0)
{
    print(" \(year) is leap year")
}
else
{
    print("not a leap year")
}