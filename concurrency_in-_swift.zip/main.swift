import Foundation
/*
func queueTesting()
{
     //let myQueue=DispatchQueue(label:"prashant.serial.queue")
     let myQueue=DispatchQueue(label:"prashant",attributes:.concurrent)
    
    //thread first
     //myQueue.sync
    //myQueue.async {
        print("task 1 started")
        for i in 1...5
        {
            print("\(i) time of a number is \(i*5)")
        }
        print("task 1 finished")
    }
    
    //myQueue.sync
    myQueue.async {
        print("task 2 started")
        
        for i in 1...3 {
            print("\(i) times [task 2] is \(i*5)")
        }
        print("task 2 finsihed")
    }
}
queueTesting()

*/

/*
// functions

func listPhotos(inGallery name: String) async -> [String] {
    let result = // ... some asynchronous networking code ...
    return result
}
}

let photoNames = await listPhotos(inGallery: "Summer Vacation")
let sortedNames = photoNames.sorted()
let name = sortedNames[0]
let photo = await downloadPhoto(named: name)
show(photo)
*/




//Actor In swift Concurrency

class User
{
    let id:String
    let name:String
    
    
    init(_ id:String,_ name:String)
    {
        self.id=id
        self.name=name
    }
}


class userStorage
{
    private var store=[String:User]()
   // private let queue=DispatchQueue(label:"coom.prashant")
    
    func get(_ id:String) ->User?
    {
     //queue.sync
     //{
        return self.store[id]
     //}
    }
    func save(_ user:User)
    {
    // queue.sync
    // {
        self.store[user.id]=user
     //}
    }
    
    init()
    {
        
    }
}


let user=User("1","pj")

let storage=userStorage()
storage.save(user)

let gettting=storage.get("1")
//print(String(describing:gettting))

//print("\(gettting!.id) \(print(gettting!.name))")


/*
actor userStorage
{
    private var store=[String:User]()
    func get(_ id:String) ->User?
    {
        return self.store[id]
    }
    func save(_ user:User)
    {
        self.store[user.id]=user
     }
    init(){ }
}


let storage=userStorage()
Task{
let user=User("1","pj")
await storage.save(user)

let gettting=await storage.get("1")
//print(String(describing:gettting))

print(gettting)
}
*/
