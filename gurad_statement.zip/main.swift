/*
//if else use in compare to guard
func Naming(_ name:String?)
{
    if name==nil
    {
        print("cant be empty fill again")
    }
    else 
    {
        print("name is \(name!)")
    }
    
    print("hello admin i have printed the details")   //in if else case it will be printed even if the condition is nil
} 

Naming("prashant")
Naming(nil)
*/


//USE OF GUARD STATEMENT


func Naming1(_ userName:String?)
{
   
    guard userName != nil else    //use of Guard STATEMENT
    {
        print("the name is nil so fill again")
        return
    }
    print("hello \(userName!),how can i help you?")
    
    
    /*guard userName != nil, isValid(userName!) else {
        print("value of username is not nil")
        return
    }
    print("printed after guard excution")
}
func isValid(_ name:String) ->Bool{
    return name.count==4 ? true:false
}
*/

Naming1("pcx")
//Naming1(nil)     //as cond failed do not excure the print used in outer 




