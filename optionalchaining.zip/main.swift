// starting with optional 

/*
var token:Int?=4
var a:Int?
//print(a!)    //will give a  error as value not there but forcing to unwrap

print(token!)   // forced unwrapping

if token != nil     //with an if condition
{
    print(token!)
}


//use of optional chaining

var age:Int?=5

if let newAge=age{
    print(newAge)
}
*/
// *******************************************************************************************************

var optionalNumber:Int?
optionalNumber=33


//use of if let
if let number=optionalNumber
    {
    print("executed and the number is \(number)")
    }
    else
    {
        print("I  dont have a value")
    }



//Using guard 


func tripleNumber(_ number:Int?) {

guard let number=number else {
    print("exiting")
    return
  }
  print("3 times of a number is:\(number*3)")

}

tripleNumber(optionalNumber)



//using a optional chaining

struct Student
{
    var name:String
    var roll:Int
    var school:String
    
}

var stdents:Student?

students=Student(name:"prashant",roll:1,school:"DAV")

 let profile=stdents?.roll    //will not givr any output but do not fail liek foece unwrapping
  
 if let profile=profile {
     print("name is \(stdents?.name) and roll is \(profile)")
     
     print("the new roll is \(profile+4)")
 }
//optional chaining with class Example
/*
class Emp {
    var name:manager?
}
class manager
{
    var position="manager"
}

let result=Emp()
if let newPos=result.name?.position    //will prevent from crashing and if will use ! then runtime error
{
    print(newPos)
}
else{
    print("not able to retrive")
}

// To acess the of we need to assign manager instance  to result.name
result.name=manager()

if let newPos=result.name?.position    //will prevent from crashing and if will use ! then runtime error
{
    print(newPos)
}
else{
    print("not able to retrive")
}

let result1=manager()
print(result1.position)


*/


/*
// optional chaining complex query


class Person {
    var residence: Residence?
}


class Residence
{
    var rooms:[Room]=[]
    var noOfRooms:Int{
        return rooms.count
    }
    
    subscript(index:Int) ->Room{
        
        get
        {
            return rooms[index]
        }
        set{
            rooms[index]=newValue
        }
    }
    
    func printNoOfRooms()
    {
        print("the no of rooms are \(noOfRooms)")
    }
    
    var address:Address?
}


class Room
{
    var name:String
    
    init(name:String)
    {
     self.name=name   
    }
}

class Address {
    var buildingName: String?
    var buildingNumber: String?
    var street: String?
    func buildingIdentifier() -> String? {
        if let buildingNumber = buildingNumber, let street = street {
            return "\(buildingNumber) \(street)"
        } else if buildingName != nil {
            return buildingName
        } else {
            return nil
        }
    }
}
//Accessing Properties Through Optional Chaining

let john = Person()
if let roomCount = john.residence?.noOfRooms {
    print("John's residence has \(roomCount) room(s).")
} else {
    print("Unable to retrieve the number of rooms.")
}


/*
let someAddress = Address()
someAddress.buildingNumber = "29"
someAddress.street = "Acacia Road"
john.residence?.address = someAddress    //will fail as cureently nil

*/
func createAddress() -> Address {
    print("Function was called.")

    let someAddress = Address()
    someAddress.buildingNumber = "29"
    someAddress.street = "Acacia Road"

    return someAddress
}
john.residence?.address = createAddress()           //nothing printed but no fall back

/*func printNumberOfRooms() {
    print("The number of rooms is \(numberOfRooms)")
}*/

if john.residence?.printNoOfRooms() != nil {
    print("It was possible to print the number of rooms.")
} else {
    print("It was not possible to print the number of rooms.")
}


//for subscript

john.residence?[0] = Room(name: "Bathroom")

let johnsHouse = Residence()
johnsHouse.rooms.append(Room(name: "Living Room"))
johnsHouse.rooms.append(Room(name: "Kitchen"))
john.residence = johnsHouse

if let firstRoomName = john.residence?[0].name {
    print("The first room name is \(firstRoomName).")
} else {
    print("Unable to retrieve the first room name.")
}
// Prints "The first room name is Living Room."

*/


