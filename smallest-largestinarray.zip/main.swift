
var arr:[Int]=[74,34,74,54,8]
var min=arr[0]
var max=arr[arr.count-1]

print(arr.max()!)    //shortcut to find max and min
print(arr.min()!)


for i in 0..<arr.count
{
    if min>arr[i]
    {
        min=arr[i]
    }
}
print("the minimum element in array is",min)

//maximum element in an array

for j in 0..<arr.count
{
    if max<arr[j]
    {
        max=arr[j]
    }
}
print("maximum is",max)