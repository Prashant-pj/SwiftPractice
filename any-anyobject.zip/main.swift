import Foundation

class Employee
{
    let EmployeeName:String?="Ravi"
}

struct product
{
    let name:String="headphone"
    
}

let a:Int=1
let b:String="prashant"
let c:Float=1.3
let d:Double=2.3432

let e:(Int,String)=(12,"mobile")
let f:[String]=["ravi","swift","aman"]


let objclass:Employee=Employee()
let objproduct:product=product()

debugPrint(a)
debugPrint(b)
debugPrint(c)
debugPrint(d)
debugPrint(e)

e.forEach
{
(value) in
debugPrint("value of array is \(value)")
}

