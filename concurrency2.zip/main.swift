//Dsipatchqueue and Dispatch Group
import Foundation
/*
class viewing
{
    func notifyDispatchGroup()
    {
    let group=DispatchGroup()
    let queue=DispatchQueue(label:"com.pj.1")
    let someQueue=DispatchQueue(label:"com.pj.2")
    
    queue.async(group: group)
    {
    for _ in 0...25{
        print("task 1 running ")
    }
    }
    queue.async(group: group)
    {
        for _ in 0...15{
        print("task 2 on queue running")
    }
    }
    someQueue.async(group: group)
    {  
    for _ in 0...35
    {
        print("task 2 someQueue running")
    }
    }
    group.notify(queue:DispatchQueue.main)
    {
    print("all jobs completed")
    }
    /*
    if group.wait(timeout: .now() + 5) == .timedOut
    {
    print("tired of waiting")
    }
    else
    {
     print("all job done")
   }
*/
}
}
let result=viewing()
result.notifyDispatchGroup()
*/
//**************************************************************
/*
class viewing1
{
    func notifyDispatchGroup1()
    {
    let group=DispatchGroup()
    let queue=DispatchQueue.global(qos:.userInitiated)
    queue.async(group: group)
    {
        print("task 1 running ")
        Thread.sleep(until: Date().addTimeInterval(10))
        print("end task 1")
      }
    queue.async(group: group)
    {
        print("task 2 on queue running")
         Thread.sleep(until: Date().addTimeInterval(4))
         
         print("job 2 end")
    }
if group.wait(timeout: .now() + 5) == .timedOut
{
    print("tired of waiting")
}
else
{
    print("all job done")
}
}
}
let result1=viewing1()
result1.notifyDispatchGroup1()

*/


//Actor
/*
class Flight
{
    let compant:String="Air India"
    var availableseat:[String]=["1A","1B","1C"]
    
    let barrierQueue:DispatchQueue=DispatchQueue(label:"barrierQueue",attributes:.concurrent)  //creating a seperate DispatchQueue to handle race condition
    
    
    func getAvaialbleSeat() ->[String]
    {
    barrierQueue.sync(flags: .barrier)
    {
       return availableseat
    }
    }
    
    func bookSeat() ->String
    {
        barrierQueue.sync(flags: .barrier)    //manually adding condition
        {
        let bookSeat=availableseat.first ?? ""
        availableseat.removeFirst()
        return bookSeat 
    }
    }
}

let flight:Flight=Flight()

let queue1=DispatchQueue(label:"Com.prashant.A")
let queue2=DispatchQueue(label:"com.prashant.B")


queue1.async
{
let bookedseat:String=flight.bookSeat()
print("bookedseat is \(bookedseat)")
    
}
queue2.async{
    let availableseats:[String]=flight.getAvaialbleSeat()
    print("availableseats are \(availableseats)")
}


*/

//**************************************************************************************************************
actor Flight
{
    let company:String="Air India"
    nonisolated var comp:String {
        "vistara company"
    }
    var availableseat:[String]=["1A","1B","1C"]
    
    func getAvaialbleSeat() ->[String]
    {
    barrierQueue.sync(flags: .barrier)
    {
       return availableseat
    }
    }
    
    func bookSeat() ->String
    {
        barrierQueue.sync(flags: .barrier)    //manually adding condition
        {
        let bookSeat=availableseat.first ?? ""
        availableseat.removeFirst()
        return bookSeat 
    }
    }
}

let flight:Flight=Flight()

let queue1=DispatchQueue(label:"Com.prashant.A")
let queue2=DispatchQueue(label:"com.prashant.B")


queue1.async
{
Task{
//print("companty is \(flight.company")
//print("comp is \(flight.comp"))

let bookedseat:String=await flight.bookSeat()
print("bookedseat is \(bookedseat)")
   } 
}
queue2.async{
Task
{
    let availableseats:[String]=await flight.getAvaialbleSeat()
    print("availableseats are \(availableseats)")
}
}