
//understanding closures with functions

func addTwo(_ num1:Int,_ num2:Int) ->Int{
    return num1+num2
}

let result = addTwo(2,5)
print(result)

var addTwoNumber=addTwo    //assigning function to variable
let res=addTwoNumber(4,6)
print(res)

print("****************************************************************************************")

//closures

var addTwoNum:(Int,Int) ->Int =
{                           
    (num1,num2) 
    in
    return num1+num2
}

/*
var addTwoNum:(Int,Int) ->Int =
{                           
    return $0+$1         // using $0 and 1 points to element 1 and 2nd
}
*/
let res1=addTwoNum(4,6)
print(res1)


//Example 2nd

var addClosures:(_ num1:Int,_ num2:Int)-> Int =
{

    //(_ num1:Int,_ num2:Int) ->Int
    (num1,num2)
    
    in
    return num1+num2
}

let res2=addClosures(54,6)
print(res2)



//Example 3
//TYPEALIAS using closure syntax

typealias addAlias=(_ num1:Int,_ num2:Int)-> Int 


var addClosures1:addAlias =               //using alias instead of declareation
{

    //(_ num1:Int,_ num2:Int) ->Int
    (num1,num2)
    
    in
    return num1+num2
}
let res3=addClosures1(65,5)
print(res3)

//********************************************************************************************************

//Function call sequence with closures 

func printTime(isMorning:Bool,name:() -> String)
//func printTime(isMorning:Bool,name:@autoclosure() -> String)   //autoclosure reduces code while calling but usually not recommended
{
    if(isMorning)
    {
     debugPrint("Good morning \(name())")
     
    }
    
}

func assignName(name:String)->String
{
    debugPrint("assigned name is called")
    return name 
}


//printTime(isMorning:true, name:assignName(name:"prashant"))
//printTime(isMorning:false,name:assignName(name:"prashant"))



printTime(isMorning:true) {()->String
           in
           assignName(name:"pj")
           }


