struct Employee {
var name = "" 
var salary=0 
var role="" 

func doWork() 
{
print("doing Work") 
print("my name is \(name) having salary \(salary) in a role of \(role)") 
    
} 
    
} 
var c :Employee=Employee(name:"prashant",salary:450000,role:"software eng") //object // c.name="prashant" // c.salary=76543 // c.role="tech" c.doWork()