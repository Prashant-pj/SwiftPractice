
//All sorting techniques implementation using Swift 

/*
//bubbleSort technique to sort an array 
var temp=0
func bubbleSort(arr:[Int]) ->[Int]
{
var array=arr
for _ in 0..<array.count-1
{
for i in 0..<array.count-1
{
    if (array[i]>array[i+1])
      {
			temp = array[i];
			array[i] = array[i+1];
			array[i+1] = temp;
		}
	
}
}
return array
}

let arr1 = [64, 34, 25, 12, 22]
print(bubbleSort(arr:arr1))     // calling a function


 */
 
 print("**********************************************************************************************")
 
 /*
 //sorting using selection sort
 
 var arr=[23,53,4,78,84,34,86,76]
 
 func selSort(arr:[Int]) ->[Int]
 {
  var arr=arr
  
  for i in 0..<arr.count-1
  {
      var minIndex=i     // minIndex and comparing with it 
      for j in i+1..<arr.count-1
      {
          if(arr[j]<arr[minIndex])
          {
              minIndex=j
          }
      }
      arr.swapAt(i,minIndex)
      print(arr)
  }
  return arr
     
 }
 selSort(arr:arr)
 
 */
 
 print("************************************************************************************************************")

/* 
//using merge sort

func mergeSort(array:[Int]) ->[Int]
{
    guard array.count>1 else{
        return array
    }
    
    let leftArray=Array(array[0..<array.count/2])
    let rightArray=Array(array[array.count/2..<array.count])
    
    return merging(mergeSort(array:leftArray),mergeSort(array:rightArray))
}

func merging(_ left:[Int],_ right:[Int])->[Int]
{
  var mergedArray:[Int]=[]
  var left = left
  var right = right
  
  while left.count>0 && right.count>0 {
      if left.first!<right.first!
      {
         mergedArray.append(left.removeFirst())
      }
         else
         {
             mergedArray.append(right.removeFirst())
         }
      
  }
  return mergedArray+left+right     //getting all the elements 
}
 
 var numbers=[64,43,6,4,75,86,7]
 print(mergeSort(array:numbers))
 
 */
//*************************************************************************************************************

/*
//quick sort method to sort an array 


//var unsortedArray=[35,43,12,45,76,34]

var unsortedArray:[Int]=[]               //taking Input from user to get an array
for _ in 1...5{
    print("elements of unsorted are:")
    unsortedArray.append(Int(readLine()!)!)
}
func quickSort(array:[Int]) ->[Int]
{
    var less=[Int]()
    var equal=[Int]() 
    var grater=[Int]()
    
    if array.count>1
    {
      let pivot=array[0]   //could be any 
      for x in array 
      {
      if x<pivot {
          less.append(x)
         
      }
       if x==pivot
      {
          equal.append(x)
      }
      if x>pivot{
          grater.append(x)
      }
      }
      return (quickSort(array:less)+equal+quickSort(array:grater))
      }
   else{
       return array
       }
  }
    let sortedArray=quickSort(array:unsortedArray)
    print("sorted arraay elements are",sortedArray)


// ********************************************************************************************************
*/



//Insertion sort

var numbers:[Int]=[]
for _ in 0..<5
{
    numbers.append(Int.random(in:0..<1000))   //geerating random no 
 }

    var sorted:[Int]=[]
    
    for num in numbers
    {
        let sortedArray=sorted.count
        
        for index in 0..<sorted.count
        {
            if (num<sorted[index])
            {
                sorted.insert(num,at:index)
                break
            }
        }
        if sortedArray==sorted.count
        {
            sorted.append(num)
        }
    }

print(numbers)
print(sorted)

