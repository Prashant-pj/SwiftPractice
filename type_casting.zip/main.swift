
//Type casting
/*
class person
{
    func naming()
    { 
       print("I am having name")
    }
    }
    
    class Employee:person
    {
        func isEmployee()
        {
            print("I a also am Employee")
        }
    }
    
    class Student:Employee
    {
        func isStudent()
        {
            print("am also a student")
        }
    }
    
    
    let stu=Student()
    stu.naming()
    stu.isStudent()
    stu.isEmployee()
    
    let newSt=stu as Employee
    newSt.naming()
    newSt.isEmployee()
    
    //newSt.isStudent()   //will not work as we have typecasted to Employee
   
   
   
   var name="prashant" as Any    // typecasted it to Any 
   var number=20 as Any
   
   var newArray=[name,number]   //2 diff types of data in an array because of Any
   print(newArray)
   
   
   //DownCasting =performed after an up casting
   
   let newValue=newArray[1] as! Int
 //  let newValue1=newArray[0] as! Int   //force typecasting will fail and give na error 
   
   
   //safe downcasting
   
   let newValue2=newArray[1] as? Int
   let newValue3=newArray[0] as? Int   // will not give an error instead give nil
   print(newValue3)
  
  
  //Grouping
  
  let nameOne=Employee()
  let nameTwo=Student()
  let nameThree=Employee()
  let nameFour=Student()
  
  
  //let people:[person]=[nameOne as person,nameTwo as person,nameThree as person,nameFour as person]  //not req as swift automatically detects
  let peoples:[person]=[nameOne,nameTwo,nameThree,nameFour]
   
   //for downcasting
  for people in peoples
  {
  if  let emp=people as? Employee
  {
      emp.isEmployee()
  }
  if let stud=people as? Student
  {
      stud.isStudent()
  }
  }
   
   
   
   */
   

class MediaItem {
    var name: String
    init(name: String) {
        self.name = name
    }
}

class Movie: MediaItem {
    var director: String
    init(name: String, director: String) {
        self.director = director
        super.init(name: name)
    }
}

class Song: MediaItem {
    var artist: String
    init(name: String, artist: String) {
        self.artist = artist
        super.init(name: name)
    }
}

let library = [
    Movie(name: "Casablanca", director: "Michael Curtiz"),
    Song(name: "Blue Suede Shoes", artist: "Elvis Presley"),
    //Movie(name: "Citizen Kane", director: "Orson Welles"),
    Song(name: "The One And Only", artist: "Chesney Hawkes"),
    Song(name: "Never Gonna Give You Up", artist: "Rick Astley")
]


var movieCount = 0
var songCount = 0

for item in library {     //operator to check type or a type checker chedcker operator -is
    if item is Movie {
        movieCount += 1
    } else if item is Song {
        songCount += 1
    }
}

print("Media library contains \(movieCount) movies and \(songCount) songs")


let media1=MediaItem(name:"pj")
if media1 is MediaItem{
    print("media type")
}
else
{
    print("not a media type")
}


/*
var x="23"
var y:Any = 3456

if x is String
{
    print(x)
}
else
{
    print("not a int")
}

if let anyVar = y as? Int {
    print("\(y) converted to Int as  \(anyVar)")
}

var a:Any=23
if let A=a as? String
{
    print(A)
}
*/