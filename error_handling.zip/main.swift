//Error handling Concept

/*
//throgh normal if else
func checkHeight(_ height:Int)
{
    if height>200
    {
        print("Too long")
    }
    else if height<140
    {
        print("Too short")
    }
    else
    {
        print("enjoy")
    }
}

checkHeight(234)
*/

//********************************************************************************************************
//Now using error handling removes the drawbacks of if else like complicated func and the modularity

/*
//designning a error using enum
enum heightError : Error
{
    case maxHeight
    case minHeight
}

//calling function
func checkHeight(_ height:Int) throws    //propogating throgh throws
{
  if height>200
   {
    throw heightError.maxHeight
    }
    else if height<140
    {
        throw heightError.minHeight
    }
    else
    {
        print("Enjoy")
    }
}


//handling the error using do try catch block

do{
    try checkHeight(201)
    }
    catch heightError.maxHeight
     {
        print("Too long") 
     }
     catch heightError.minHeight
     {
         print("too short")
     }



//Error Handling while object Initialization\

enum nameError:Error {
    case noName
}

class Course {
    var name:String
    
    init(name:String) throws {    
        if name == ""
        {
            throw nameError.noName
        }
        else{
            self.name=name
            print("sucessfully printed")
        }
    }
}

do {
    let res=try Course(name:"Ios")    //can use _ id we dont need to use the varible 
}
catch
{
    print("you must enter the name ")
}


let newCourse=try? Course(name:"prashant") 


let newCourse1=try? Course(name:"")
print(newCourse1)


//using force unwrappig

//let newCouerse2=try! Course(name:"")    //will give a error in case of forced unwrapiing

*/


//**************************************************************************************************


/*
enum ErrorsToThrow:Error
{
    case fileNotFound
    case fileNotReadable     // can also add a parametr with an case
    case fileSizeIsTooHigh
}

func readingData(data:String) throws ->String 
{
  //specify different condition for difrrent case
  
    if  fileNotFound    
    {
        throw ErrorsToThrow.fileNotFound
    }
    else if fileNotReadable 
    {
        throw ErrorsToThrow.fileNotReadable
    }
    else if fileSizeIsTooHigh
    {
        throw ErrorsToThrow.fileSizeIsTooHigh
    }
    return "some file from data"

}

do {
let dataFromString = try? readingData(data: "files")
} 
catch ErrorsToThrow.fileNotFound 
{
       print("fileNotFound")
} 
catch ErrorsToThrow.fileNotReadable 
{
      print("fileNotReadable")
} 
catch ErrorsToThrow.fileSizeIsTooHigh {
     print("fileSizeIsTooHigh")
}

*/

//****************************************************************************************************
/*
enum allError:Error{
    case nameIsEmpty
}

class human
{
    var name:String?
    
    init(name:String?) throws {
        
        guard let name=name else
        {
            throw allError.nameIsEmpty
            //return
        }
        self.name=name
        print("\(name)")
    }
}

do{
    let _=try human(name:nil)
    
}
catch allError.nameIsEmpty
{
    print("have not specified the name")
}

let humanObj1 = try? human(name: "amar")
print(humanObj1)                      // returns Human? optional type
let humanObj2 = try? human(name: nil)
print(humanObj2)                     // nil (humanObj2 is an optional which can handle nil)



*/



