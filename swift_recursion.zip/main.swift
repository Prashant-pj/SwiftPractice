
//Recursion
func countDown(number: Int) {
  print(number)
  if number == 0 {
  print("Countdown Stops")
  }
  else {
    countDown(number: number - 1)
  }
}
print("Countdown:")
countDown(number:3)

//Factorial Of a number

func factorial(_ fact: Int) -> Int {
  if fact == 0 {
    return 1
  } 
  else {
    return fact * factorial(fact - 1)
  }

}
var number = 3

// function call
var result = factorial(number)
print("The factorial of 3 is", result)