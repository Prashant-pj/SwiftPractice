// use of generics in swift

/*
using a sipmle func
func swapMydata(_ x:inout Int,_ y: inout Int) {

let temp=x
   x=y
   y=temp
}

var a=6
var b=10

swapMydata(&a,&b)
print(a,b)
*/

/*
//using generics
func swapMydata<T>(_ x:inout T,_ y: inout T) {

let temp=x
   x=y
   y=temp
}

var a=6
var b=10
var c=8.9
var d=9.8
var str1="prashant"
var str2="jha"
swapMydata(&a,&b)
print(a,b)
swapMydata(&c,&d)
print(c,d)

swapMydata(&str1,&str2)
print(str1,str2)
*/

struct Stack<Element> {

    var items: [Element] = []
    mutating func push(_ item: Element) {
        items.append(item)
    }
    mutating func pop() -> Element {
        return items.removeLast()
    }
}

var st=Stack()
st.push(2)
st.push(4)
print(st)
let ab=st.pop()
print(ab)


/*
//another Example
class Math<T:Numeric>
{
  func add(_ x:T,_ y:T) ->T
  {
      return x + y
  }
  func mul(_ x:T,_ y:T) ->T
  {
      return x*y
  }
}

let m1=Math<Int>()
let a=m1.add(3,5)
let b=m1.mul(3,5)
print(a)
print(b)


let m2=Math<Float>()
let c=m2.add(5.8,4.3)
let d=m2.mul(5.5,7.7)
print(c)
print(d)

*/












