//extension in Swift

//extension for existing data types
/*
extension Double {
    
    func convertToFahreneit() ->Double
    {
        return ((self * 1.8000)+32)
    }
    func convertToCelcius() ->Double
    {
        return ((self - 32)/1.8000)
    }
}
var celciusTemp:Double=34
var FahTemp:Double=65

print("celciusTemp to Fahreniet:",celciusTemp.convertToFahreneit())
print("Fahreniet to celciusT:",FahTemp.convertToCelcius())

//--iuyt***********************************************************************************************

var x:Int=7654

extension Int{
    func countDigit() ->Int   //func to count digit of a number
    {
        let c=String(self)
        return c.count
    }
}
print(x.countDigit())


extension Int {
    func repetitions(task: () -> Void) {
        for _ in 0..<self {
            task()
        }
    }
}
3.repetitions {
    print("Hello!")
}


//extension with prefdefined data typesextension 

Int {
   var add: Int {return self + 100 }
   var sub: Int { return self - 10 }
   var mul: Int { return self * 10 }
   var div: Int { return self / 5 }
}

let addition = 3.add
print("Addition is \(addition)")

let subtraction = 120.sub
print("Subtraction is \(subtraction)")

let multiplication = 39.mul
print("Multiplication is \(multiplication)")

let division = 55.div
print("Division is \(division)")

let mix = 30.add + 34.sub
print("Mixed Type is \(mix)")


//Extenstion with initializer

struct sum {
   var num1 = 100, num2 = 200
}

struct diff {
   var no1 = 200, no2 = 100
}

struct mult {
   var a = sum()
   var b = diff()
}

let calc = mult()
print ("Inside mult block \(calc.a.num1, calc.a.num2)")
print("Inside mult block \(calc.b.no1, calc.b.no2)")

let memcalc = mult(a: sum(num1: 300, num2: 500),b: diff(no1: 300, no2: 100))
print("Inside mult block \(memcalc.a.num1, memcalc.a.num2)")
print("Inside mult block \(memcalc.b.no1, memcalc.b.no2)")

extension mult {
   init(x: sum, y: diff) {
      let X = x.num1 + x.num2
      let Y = y.no1 + y.no2
   }
}

let a = sum(num1: 100, num2: 200)
print("Inside Sum Block:\( a.num1, a.num2)")

let b = diff(no1: 200, no2: 100)
print("Inside Diff Block: \(b.no1, b.no2)")


*/

class Person
{
     var name:String=""
     var age:Int=8000
     
     func display()
     {
         print("name is:\(name) and age is \(age)")
     }
}

protocol Process     // protocol in swift 
{
    func processing()
}

extension Person:Process
{
    func isVoter() ->Bool
    {
        /* if age>=18     //using if else
         {
             return true
         }
         else
         {
             return false
         }
         */
         guard age>=18 else {       // uisng guard statement
             print("not eligible")
             return false
             }
             print("eligible to vote")
             return true
        
    }
    func processing()     // defuning the func in protocol
    {
        print("Person is processing")
    }
}
var per1=Person()
per1.name="Prashant"
per1.age=22
per1.display()
print(per1.isVoter())
per1.processing()
print("______________________________________________________________________________________________")

var per2=Person()
per2.name="Aman"
per2.age=16
per2.display()
print(per2.isVoter())
per2.processing()






















