 /*
//sum of n natural no in swift

//var num = 10
print("enter a number:")
var num=Int(readLine()!)! 
var sum=0
for i in 1...num
{
    sum+=i
}
print(sum)
*/

//Sum of elements in arary 
var arr=[23,4,42,33,64,3]
var sum=0
for i in 0..<arr.count
{
    sum=sum+arr[i]
}
print(sum)