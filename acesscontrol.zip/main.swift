
/*

//private class Student
class Student
{
    var name="prashant"
    private var roll:Int=1
    func details() 
    {
        print("name is \(name) and roll is \(roll) ")
        
    }
    
}

var output=Student()
output.details()

class person
{
let per=Student()

func printing() ->String
{
  return per.name
   //return per.roll    //roll cant be accessed as declared as private 
}
}

var per1=person()
per1.printing()

*/
//use of filePrivate 
/*
//filePrivate class Student
class Student
{
    var name="prashant"
    fileprivate var roll:Int=1
    
    func details() 
    {
        print("name is \(name) and roll is \(roll) ")
        
    }
    
}

var output=Student()
output.details()

class person
{
let per=Student()

func printing() 
{
   print( per.name)
   print(per.roll)   //roll can be accessed as declared as fileprivate 
}
}

var per1=person()
per1.printing()

*/

//_____________________________________________________________________________________
//internal is the default one so lets check public and open
/*
class Student
{
    public var name="prashant"
    internal var roll:Int=1
    fileprivate var total=50
    open var marks=46
    

    func details() 
    {
        print("name is \(name) and roll is \(roll) ")
    }}
var output=Student()
output.details()

class person
{
let per=Student()
func printing() 
{
 print(per.name)
 print(per.roll)  
 print(per.total)
 print(per.marks)

}
}
var per1=person()
per1.printing()

*/



//_______________________________________________________________________________________________

/*
open class openclass
{
    init()
    {
        }
    public func publicFunc()  //can access anything even from diff prject but cant be overidden or inherited
    {
        print("public access control")
    }
    internal func internalFunc()    // can access any file and any thing but inside this project only
    {
        print("internal or default access control")
    }
    open func openFunc()  //can be acaceswed from anywhere 
    {
        print("open access control")
    }
}

let openObj= openclass()
openObj.publicFunc()
openObj.internalFunc()
openObj.openFunc()

*/
//_______________________________________________________________________________________________

public class A       // a public class can be inherited inside a module where its declared but can't be inherited or overridden  outside it
{
    var name="prashant"
}
class B:A
{
    func abc()
    {
        print(name)
    }
}
let obj=B()
obj.abc()