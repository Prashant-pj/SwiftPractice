//if else with input from user

/*
var age:Int=0
print("Enter your age:")
age = Int(readLine()!)!

if (age>=18)
{
    print("you are eligible to drive")
}
else 
{
    print("you are not eligible to drive")
}

*/
// *************************************************************************************************
/*
var firstName:String = "abhishek"
var lastName:String = "kumar"
let gender:String = "Male"
var age:Int = 22
var cashOnHand:Double = 500
var hasChildren:Bool = false

if(hasChildren == true){
    print("you  are now became parent!")
}else if(age > 21)
{
    print("eligible to marry")
}else{
    print("I'm young and I can do what I want so gimme that game!")
}

*/
// ********************************************************************************************************************
//Switch operator   
//example of calculator
/*
var StroOperator:String
print("enter the type of operator")
StroOperator=readLine()!

var a:Int=0
var b=0
print("enter the value of a:")
a = Int(readLine()!)!
print("enter the value of b :")
b = Int(readLine()!)!

var result:Int
switch StroOperator{

    case "+":
 result=a+b
        print(result)
   
   case "-":
     result=a-b
     print(result)
     
   case "x","*":
    result=a*b ;print(result)
   
   case "/":
  
    result = a/b
    print(result)
  
  default:
  
      print("invalid opearator")
  
       
}
*/

//switch with value bindings

let Point = (2, 0)
switch Point {
case (let x, 0):
    print("on the x-axis with an x value of \(x)")
case (0, let y):
    print("on the y-axis with a y value of \(y)")
case let (x, y):
    print("somewhere else at (\(x), \(y))")
}



