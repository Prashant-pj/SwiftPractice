//Optional chainning practice 
//Program for Optional Chaining with ? Operator

class Exam
{
    var student:Subject?
}
class Subject
{
    var sub="maths"
}
let marks=Exam()
marks.student=Subject()

if let number=marks.student?.sub    //cant acces as value not in base class
{
    print("the subject is \(number)")
}
else
{
    print("cant access")
}
//Model Class for Optional Chaining & Accessing Properties

/*
class Rectangle{
    var dimention:Circle?
}

class Circle{

    var area:[radius]=[]
    
    var areaCount:Int
    {
        return area.count
    }
    
    subscript(index:Int) ->radius
    {
        get 
        {
            return area[index]
        }
        set{
            area[index]=newValue
        }
    }
    
    func gettingArea()
    {
        print("the elemets area \(areaCount)")
    }
    
    var rectArea:Circumference?
}

class radius 
{
    var name:String
    
    init(name:String)
{
    self.name=name 
}
     
}

class Circumference
{
    var name:String?
    var number:String?
    
    
    func outputValue()->String?
    {
       if name != nil
       {
           return name
       }
       else if number != nil{
           return number
       }
       else
       {
           return nil
       }
    }
}

var result=Rectangle()
if let res=result.dimention?.areaCount
{
    print("area is accesible and is \(res)")
}
else
{
    print("rectangle area not specified")
}

*/