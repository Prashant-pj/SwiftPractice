let ageString = "42"
let ageInt = Int(ageString)
print(ageInt)
