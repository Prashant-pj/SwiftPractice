/*struct TimesTable {
    let multiplier: Int  //=3
    subscript(index: Int) -> Int {
        return multiplier * index
    }
}
let threeTimesTable = TimesTable(multiplier: 3)
print(threeTimesTable[5])

*/

/*
//Example 2

struct countingNumber
{
var numbers=["one","two","three","Four","Five"]
}
//for normal access
let countNo=countingNumber()
print(countNo.numbers[2])

//using subscript

subscript(index:Int) ->String 
{
    return numbers[index]
}
}
let countNo=countingNumber()
print(countNo[4])   //now can direclty access

*/


struct HealthInfo
{
    var Info=["height":175,"weight":70]
    
    subscript(key:String) ->Double
    {
        if let newInfo==Info[key]
        {
            return newInfo
        }
        else
        {
            return 0
        }
    }
}

let healthInfo=HealthInfo()
let myHeight=healthInfo["height"]
print(myHeight)

