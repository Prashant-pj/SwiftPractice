/*class person
{
    var name=""
    
    init()                    //default Initializer
    {
        name="prashant"
    }
    
    init(_ name:String)   //initializer with an parameter
    {
        self.name=name
    }
}
/*
let myPerson=person()
print(myPerson.name)

let myPerson1=person("abhinav")
print(myPerson1.name)

*/
class Employee:person
{
    var salary=0
    var role=""
    
    override init()    //overriding the defaukt initialzer of base class
    {
      super.init()  
    }
    

      override init(_ name:String)    //overriding the initializer
    {
        super.init(name)
        self.role="software Engineer"
    }
    
    func doWork()
    {
       
        print("my name is \(name)  having salary \(salary) in a role of \(role)")
    }
}

var c:Employee=Employee()  
//var c:Employee=Employee("abhinav")     //object
//c.name="prashant1"

c.salary=76543
c.role="tech"

c.doWork()


class Manager:Employee
{
    var teamSize=0
    
    
    override func doWork()     //overriding the function
    {
        super.doWork()     //call the function of base class
        
        print("i am \(role) and i manage people")
    }
    
    func firePeople()
    {
        print("can also fire a Employee")
    }
}

var m=Manager("aniket")
//m.name="aniket1"   //if declaring here it can update the previos value aniket
m.salary=9876543
m.role="manager"
m.doWork()
m.firePeople()

*/

//use of Initializer nad func(Example 2)

/*class Pets{
var name:String = ""

init()
{
     name = "bunny";
}

init(_ name:String){
     self.name = name;
}

func feed(){
     print("\(name) has been fed");
}

func clean(){
     print("\(name) has taken a bath");
}

func play(){
     print("\(name) enjoyed playing with you");
}

func sleep(){
     print("\(name) went to sleep");
}
}
var pet = Pets()
print(pet.name)
var pet2 = Pets("doggy")
print(pet2.name)

*/
//use of properties,func and Initializer with another example
class boy
{
    var name=""
    
    init()
    {
        name="prashant"
    }
    
    init(_ name:String)
    {
        self.name=name
        
    }
    
    func eating()
    {
        print("boy is eating")
    }
}
class student:boy
{
    var section=""
    var roll=0
    
    
    override init(_ name:String)
    {
        super.init(name)
        
         section="c"
        //self.section="B"    //Additional init code
    }
    override func eating()
    {
        super.eating()
        print("stduent also eats")
    }
    
    func attendSchool()
    {
        print("atatends school everyday")
    }
}

class SeniorStudent:student
{
    var position=""
    
    func becomeCaptain()
    {
        print("I can becme captain")
    }
}


let boys=boy()
let boys1=boy("aman")
//boys.name="pankaj"
boys.eating()
print(boys.name)
print(boys1.name)


let students=student("piyush")
//students.name="bhaskar"
//students.section="A"
students.roll=4

students.eating()
students.attendSchool()

print("name is \(students.name) and section and roll is \(students.section) and \(students.roll)")



