
//TASK -1
//Ascending order
var numArray=[-3,-7, 1, 5 ,-20,-6,7,8]
var temp=0
func sortFunc(_ arr:[Int],_ n:Int=numArray.count) 
{
    for i in 0..<numArray.count
 {
     for j in (i+1)..<numArray.count
     {
         if(numArray[i]>numArray[j])
          {
            temp=numArray[i]
            numArray[i]=numArray[j]
            numArray[j]=temp
           }
      }
 }
 print(numArray)
 }
 
 sortFunc(numArray)


/*
var numArray=[-3,-7, 1, 5 ,-20,-6,7,8]
var temp=0
 for i in 0..<numArray.count
 {
     for j in (i+1)..<numArray.count
     {
         if(numArray[i]>numArray[j])
          {
            temp=numArray[i]
            numArray[i]=numArray[j]
            numArray[j]=temp
           }
      }
 }
     print(numArray)
 
 */
//Using predefined  function
/*let newArray=numArray.sorted()    
print(newArray)

numArray.sort()
print(numArray)
*/

//descending order   
/*let newArray=numArray.sorted(by:>)    
  print(newArray)

numArray.sort(by:>)    
print(numArray)
*/


