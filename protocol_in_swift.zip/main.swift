//protocol in swift
protocol Greet {
  var name: String { get }
  func message() 
} 
struct Employee: Greet {   //inheriting protocol
  var name = "Prashant"
  
  func message() {
    print("Good Morning", name)
  }
}
var employee1 = Employee()
employee1.message()



//  ----------------------------------------------------------------------------------------------
// create Sum protocol
protocol Sum 
{
  func addition()
}
protocol Multiplication
{
  func product()
}
struct Calculate: Sum,Multiplication {

  var num1 = 0
  var num2 = 0
  
  func addition () 
  {
    let result1 = num1 + num2
    print("Sum:",result1)
  }

  func product () 
  {
    let result2 = num1 * num2
    print("Product:",result2)
  }
}

var calc1 = Calculate()
calc1.num1 = 5
calc1.num2 = 10
calc1.addition()
calc1.product()

/*
protocol twoDshape
{
    var area:Float {get set}
    var perimeter:Float {get}
    
    var shapeName:String {get}
    
    func calculateArea()
    func calculatePerimeter()
    func displayInfo()
    
}

class Rectangle : twoDshape
{
    var length:Float=0
    var breadth:Float=0
    var area:Float=0
    var perimeter:Float=0
    
    var shapeName: String {return "Rectangle"}
    
    func displayInfo()
    {
        print("length is \(length) and breadth is \(breadth)")
        print("area is \(area) and perimeter is \(perimeter)")
    }
    
    func calculateArea()
    {
        area=length * breadth
    }
    func calculatePerimeter()
    {
        perimeter = 2 * (length + breadth)
    }
}

class Square:twoDshape
{
    var side:Float=0
    var area:Float=0
    var perimeter:Float=0
    
    var shapeName: String {return "square"}
    
    func displayInfo()
    {
        print("side is \(side)")
        print("area is \(area) and perimeter is \(perimeter)")
    }
    
    func calculateArea()
    {
        area=side*side
    }
    func calculatePerimeter()
    {
        perimeter = 4*side
    }
}

let r1=Rectangle()
r1.length=22
r1.breadth=12
r1.calculatePerimeter()
r1.calculateArea()
r1.displayInfo()

print("______________________________________________________________________________________")
let sq1=Square()
sq1.side=10
sq1.calculateArea()
sq1.calculatePerimeter()
sq1.displayInfo()
print("_______________________________________________________________________________________")

func fencingCharges(_ shape:twoDshape)
{
    let charge=shape.perimeter*240
    print("fencing charge of \(shape.shapeName) = \(charge)")
}
fencingCharges(r1)
fencingCharges(sq1)


*/




