//Understanding mutating FUNCTION

//class Rectangle
struct Rectangle
{
    var length:Int=2
    var width:Int=4
    
    func area()->Int
    {
        return length*width
    }
    
    mutating func scaleBy(_ value:Int)    //nned to use mutating in order to change with class
    {
        length*=value
        width=width*value
    }
}

var rect=Rectangle()
print(rect.area())
rect.scaleBy(3)
print(rect.area())