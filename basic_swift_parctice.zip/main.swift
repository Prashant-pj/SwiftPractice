

/*let maxLoginAttempts = 10   //let is used for constant cant be modified
var currentLoginAttempt = 0

var welcomeMessage: String="welcome prashant"

//for multiple
var red, green, blue: Double



//printing 
print(welcomeMessage)

//printing multiple on single line  using a semicolon
print(maxLoginAttempts);print(currentLoginAttempt)


//print with interpolation   
var name = "prashant"
print("hello mr \(name)")

*/ 
//use of multiline comments 

//Understanding the Data types
var firstName:String = "pankaj"     //String
var lastName:String = "kumar"
let gender:String = "Male"  
var age:Int = 30                   //Int
var cashOnHand:Double = 500       //Double by default have yo specify for a float
var variablePay:Float=5400.5   //Float
var hasChildren:Bool = false    //bool

print(firstName)
print(lastName)
print(gender)
print(age)
print(cashOnHand)
print(variablePay)
print(hasChildren)



