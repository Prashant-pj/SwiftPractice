class BankAccount
{
    var accNo:Int=0
    var name:String=""
    var balance:Float=0
    
    static var branchName:String="Lpu"
    
   init()
    {
        print("default Initializers called")
        balance=8765.87
        
    }
    init(_ accNo:Int, _ name:String, _ balance:Float)
    {
        print("paratmetrised initializer is called")
        
        self.name=name
        self.accNo=accNo
        self.balance=balance
        
        /*
        self.name="prashant"      //can also assign like this
        self.accNo=87665
        self.balance=87765.876
        */
        
    }
    
    //creating func to transfer money from one to anther
    func transferMoney(_ from:BankAccount,_ to:BankAccount,_ amount:Float)   //returning void by default
    {
        from.balance=from.balance-amount
        to.balance=to.balance+amount
    }
    // using self keyword to point out the current object
    func transferMoney(_ to:BankAccount,_ amount:Float)
    {   
        self.balance=self.balance-amount
        to.balance=to.balance+amount
    }
    
    func display() ->Void
    {
        print(accNo,"-",name,"-",balance,"-",BankAccount.branchName)
    }
    
    static func whichBranch()
    {
        print(branchName)
    }
    
}

//let result1=BankAccount()

BankAccount.branchName="jalandhar"
BankAccount.whichBranch()

let acc1:BankAccount=BankAccount(87326,"aman",15000)
acc1.display()
let acc2:BankAccount=BankAccount(87326,"prateek",10000)
acc2.display()
//acc1.transferMoney(acc1,acc2,7000)    //for func  transferMoney
acc1.transferMoney(acc2,7000)
print("---------------------------------------------------")
acc1.display()
acc2.display()



